//
// Created by shani on 12/27/16.
//

#ifndef EX4_CLOCK_H
#define EX4_CLOCK_H


class Clock {
private:
    int time;
public:
    Clock();
    void incTime();
    int getTime();
};


#endif //EX4_CLOCK_H
