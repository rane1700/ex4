//
// Created by ran on 29/12/16.
//

#ifndef SERVER_CLIENTOPS_H
#define SERVER_CLIENTOPS_H


#include "TaxiStation.h"
#include "StationInfo.h"

class ClientOps {
private:
    TaxiStation* tx;
    StationInfo sInfo;
    int driverId;

public:
    ClientOps();
    void addCab(char* buffer);
    void addTrip(char* buffer);
    void addDriver(string dInput);
    Node* getLocation();
    TaxiStation* getTs();
    int getDriverId();
    void start();
    std::string bufferToString(char* buffer,int bufferSize);
};


#endif //SERVER_CLIENTOPS_H
