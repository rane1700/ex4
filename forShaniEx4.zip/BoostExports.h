//
// Created by ran on 30/12/16.
//

#ifndef SERVER_BOOSTEXPORTS_H
#define SERVER_BOOSTEXPORTS_H
#include <boost/serialization/export.hpp>


//BOOST_CLASS_EXPORT(PointBase)
//BOOST_CLASS_EXPORT(PointHistory)
//BOOST_CLASS_EXPORT(Grid)
#endif //SERVER_BOOSTEXPORTS_H
