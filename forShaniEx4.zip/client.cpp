//
// Created by yanaiela on 12/10/16.
//
#include <iostream>
#include <fstream>
#include <sstream>
#include <boost/archive/text_oarchive.hpp>
#include <boost/archive/text_iarchive.hpp>
#include <boost/tokenizer.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/assign/list_of.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/iostreams/device/back_inserter.hpp>
#include <boost/iostreams/stream.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>

#include "Udp.h"
#include "TaxiStation.h"
#include "StationInfo.h"
#include "ClientOps.h"
#include <unistd.h>

class basic_array_source;

using namespace std;

int main(int argc, char *argv[]) {
    ClientOps co = ClientOps();
    string input;
  //  StationInfo info = StationInfo();
    Udp udp(0, 1111);
    udp.initialize();
   // TaxiStation tx = TaxiStation();
    cin >> input;
    //send driver ID to server
    co.addDriver(input);
    //Driver *driver = tx.getDriver();
    char buffer[1024];
    udp.sendData(to_string(co.getDriverId()));
    Cab* cab;
    udp.reciveData(buffer, sizeof(buffer));
    udp.reciveData(buffer, sizeof(buffer));
    co.addCab(buffer);
    //s2.flush();
    cout << buffer << endl;
   // tx.addCab(cab);

    //recive trip
    Trip* trip;
    udp.reciveData(buffer, sizeof(buffer));
    co.addTrip(buffer);
    //s3.flush();
    cout << buffer << endl;
    //tx.addTrip(trip);

    do {
        //recive 9
        udp.reciveData(buffer, sizeof(buffer));
        if (buffer[0] == '9') {
            co.start();

            //////////send server driver location
        }
    } while(buffer[0] == '7');
    udp.~Socket();
    return 0;
}