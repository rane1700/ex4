#include "SearchAlgo.h"
/**
 * Abstarct class for search algorithms
 * @return
 */
SearchAlgo::SearchAlgo() {}
//print path of map
void SearchAlgo::printPath() {}
//get next element
Node* SearchAlgo::getNext() {}