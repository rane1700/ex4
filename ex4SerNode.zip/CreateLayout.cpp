//
// Created by shani on 11/28/16.
//

#include "CreateLayout.h"
/**
 * constractor
 */
CreateMap::CreateMap(){}
/**
 * careates a layout
 * @return a new map
 */
Map createLayout(){}
/**
 * creates cab station
 */
void createStation(){}