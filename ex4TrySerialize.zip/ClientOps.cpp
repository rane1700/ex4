//
// Created by ran on 29/12/16.
//

#include "ClientOps.h"
ClientOps::ClientOps() {
    tx = new TaxiStation();
    sInfo = StationInfo();
}
void ClientOps::addCab(char* buffer) {
    std::string serial_str (buffer, sizeof(buffer));
    Cab* cab;
    //unserialize the vehicle
    boost::iostreams::basic_array_source<char> device2((char *) serial_str.c_str(), (char *) serial_str.size());
    boost::iostreams::stream<boost::iostreams::basic_array_source<char> > s2(device2);
    boost::archive::binary_iarchive ia(s2);
    ia >> cab;
    tx->addCab(cab);
}
void ClientOps::addTrip(char* buffer) {


    string serial_str (buffer, sizeof(buffer));
    Trip* trip;
    //unserialize the vehicle
    boost::iostreams::basic_array_source<char> device3((char *) serial_str.c_str(), (char *) serial_str.size());
    boost::iostreams::stream<boost::iostreams::basic_array_source<char> > s3(device3);
    boost::archive::binary_iarchive ia(s3);
    ia >> trip;
    tx->addTrip(trip);
}
void ClientOps::addDriver(string dInput) {
    Driver* d = sInfo.getDriver(dInput);
    driverId = d->getDriverID();
    tx->addDriver(sInfo.getDriver(dInput));
}
TaxiStation* ClientOps::getTs() {
    return tx;
}
int ClientOps::getDriverId() {
    return driverId;
}
void ClientOps::start() {
    tx->start();
}
std::string bufferToString(char* buffer,int bufferSize){
    std::string ret(buffer,bufferSize);
    return ret;
}