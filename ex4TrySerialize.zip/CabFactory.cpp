//
// Created by shani on 11/28/16.
//

#include "CabFactory.h"
/**
 * Constructor
 */
CabFactory::CabFactory(){}
/**
 *
 * @return cab object after analyzing input details
 */
Cab getCab(){}