//
// Created by shani on 11/28/16.
//

#include "Trip.h"
/**
 * constructor
 */
Trip::Trip(){}
/**
 * destructor
 */
Trip::~Trip(){
    delete(layout);
    return;
}
/**
 * constructor
 * @param idPar - ID of the trip
 * @param startXP - x of start point
 * @param startYP - y of start point
 * @param endXP - x of end point
 * @param endYP - y of end point
 * @param numPass - num of passengers in the trip
 * @param taa - the tarrif of the trip
 */
Trip::Trip(int idPar,int startXP,int startYP,int endXP,int endYP,int numPass,int taa) {
    RideID  = idPar;
    startX = startXP;
    startY = startYP;
    endX = endXP;
    endY = endYP;
    numPassengers = numPass;
    taarif = taa;
    layout = NULL;
}
/**
 *
 * @return metter passed
 */
double Trip:: getMetterPassed(){return 0.0;}
/**
 *
 * @return ride ID
 */
int Trip:: getRideID(){ return RideID;}
/**
 *
 * @return taarif
 */
double Trip::getTaarif() { return taarif;}
/**
 *
 * @return x of the start point
 */
int Trip::getStartX(){
    return startX;
}
/**
 *
 * @return y of the start point
 */
int Trip::getStartY(){
    return startY;
}
/**
 *
 * @return x of the end point
 */
int Trip::getEndX(){
    return endX;
}
/**
 *
 * @return y of the end point
 */
int Trip::getEndY(){
    return endY;
}
/**
 *
 * @param mapInput - the new map
 */
void Trip::setMap(Map* mapInput) {
    layout = mapInput;
}
/**
 *
 * @return the map
 */
Map* Trip::getMap() {
    return layout;
}
/**
 *
 * @return current map
 */
Node* Trip:: getMapCurrent(){
    return layout->getCurrent();
}
/**
 * starts the trip
 * @param speed - the speed of the cab
 */
void Trip::start(int speed){
    layout->run(speed);
}