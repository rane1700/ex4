#include <iostream>
#include "ParseFromString.h"
#include "MapCreator.h"
#include "StationInfo.h"
#include "Udp.h"
#include "CabsSender.h"
#include <unistd.h>


#define RECIEVE_DRIVER 1
#define RIDE 2
#define VEHICLE 3
#define DRIVER_LOCATION 4
#define STRART_DRIVING 6
#define EXIT 7
using namespace std;
int main(int argc, char **argv) {
    Udp udp(1,1111);
    udp.initialize();
    udp.sendData("9");
    string gridSize,obs,obsChain="";
    string input;
    int numObs,mission;
    int startX,startY;
    int endX,endY;
    int id;
    int numDrivers;
    std::getline(cin, gridSize);
    cin>>numObs;
    if (numObs > 0) {
        for (int i = 0; i < numObs; i++) {
            cin >> obs;
            obsChain += obs;
            obsChain += " ";
        }
    }


}
