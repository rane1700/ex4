//
// Created by ran on 27/12/16.
//
#include "Server.h"

Server::Server() {
    soc = new Udp(1,1111);
    int bla = soc->initialize();
    cout<<bla<<endl;
    flag = false;

}
void Server::setDriver() {
    char buffer[1024];
    char* charId;
    soc->reciveData(buffer,sizeof(buffer));
    charId = buffer;
    driverId = atoi(charId);

}
void Server::sendTrip(Trip *trip) {
    //serialize

    std::string serial_str;
    boost::iostreams::back_insert_device<std::string> inserter(serial_str);
    boost::iostreams::stream<boost::iostreams::back_insert_device<std::string> > s(inserter);
    boost::archive::binary_oarchive oa(s);
    oa << trip;
    s.flush();
    int x =soc->sendData(serial_str);

}
void Server::sendCab(Cab *cab) {
    std::string serial_str;
    boost::iostreams::back_insert_device<std::string> inserter(serial_str);
    boost::iostreams::stream<boost::iostreams::back_insert_device<std::string> > s(inserter);
    boost::archive::binary_oarchive oa(s);
    oa << cab;
    s.flush();
    soc->sendData("9");
    flag = true;
}
void Server::moveOn() {
    int bla =soc->sendData("9");
    cout<<bla<<endl;
}
void Server::setLocation() {
    char buffer[1024];
    soc->reciveData(buffer, sizeof(buffer));
    int xAxes,yAxes;
    char* string1 = buffer;
    ParseFromString p = ParseFromString(buffer);
    p.parse(',',&xAxes,&yAxes);
    PointHistory ph = PointHistory(PointBase(xAxes,yAxes));
    location = &ph;
}
void Server::getDriver() {
    char buffer[1024];
    soc->reciveData(buffer, sizeof(buffer));
}
void Server::getLocation(int id) {
    soc->sendData(""+id);

}
void Server::printLocation() {
    cout<<*location<<endl;
}
void Server::exit(){
    soc->~Socket();
}
bool Server::isDriverSet(){
    return flag;
}