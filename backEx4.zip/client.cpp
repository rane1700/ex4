#include <iostream>

#include <iostream>
#include <fstream>
#include <sstream>
#include <boost/archive/text_oarchive.hpp>
#include <boost/archive/text_iarchive.hpp>
#include <boost/tokenizer.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/assign/list_of.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/iostreams/device/back_inserter.hpp>
#include <boost/iostreams/stream.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include "Trip.h"
#include "Udp.h"

using namespace std;
std::string bufferToString(char* buffer,int bufferSize){
    std::string ret(buffer,bufferSize);
    return ret;
}
int main(int argc, char *argv[]) {
    std::cout << "Hello, from client" << std::endl;

    //cout << argv[1] << endl;
    Udp udp(0, 1111);
    udp.initialize();

    char buffer[1024];
    udp.sendData("12");
    udp.reciveData(buffer, sizeof(buffer));
    string data = bufferToString(buffer, sizeof(buffer));
    Trip *gp2;
    boost::iostreams::basic_array_source<char> device(data.c_str(), data.size());
    boost::iostreams::stream<boost::iostreams::basic_array_source<char> > s2(device);
    boost::archive::binary_iarchive ia(s2);
    ia >> gp2;

    udp.sendData("hello");

    cout << buffer << endl;

    udp.~Socket();
    return 0;
}